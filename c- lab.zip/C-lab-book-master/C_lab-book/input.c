#include <stdio.h> 
int main() 
{ 
    int testInteger; 
    printf("Enter an integer: "); 
    scanf("%d", &testInteger);   
    printf("Number = %d",testInteger); 
    return 0; 
} 
 