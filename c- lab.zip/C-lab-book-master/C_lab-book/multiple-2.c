#include <stdio.h>
#include <conio.h>
void main() 
{ 
 int a; 
 printf("Enter an integer\n"); 
 scanf("%d", &a); 
 printf("Integer that you have entered is %d\n", a); 
} 
