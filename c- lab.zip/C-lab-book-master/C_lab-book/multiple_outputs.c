#include <stdio.h>
int main() 
{ 
 int a; 
 float b; 
 printf("Enter integer and float:");//input 45 and 9.876678
 scanf("%d%f", &a, &b); 
 printf("You entered %d and %f", a, b); 
 return 0; 
} 